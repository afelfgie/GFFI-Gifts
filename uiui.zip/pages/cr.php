<div class="menu-notify">
<a href="javascript:;" onclick="buka('pages/dm');"><div class="menu-notify-change">Ganti Hadiah</div></a>
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, ini adalah hadiah gratisan untukmu</div>
</div> <!--- menu-notify --->
<div class="scroll">
<div class="balance kanan">
<div class="balance-content-other">
<div class="balance-currency">45 Unit</div>
<img src="img/other/cr.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/cr.png">Ambil</button>
</div>
<div class="balance kiri">
<div class="balance-content-other">
<div class="balance-currency">15 Unit</div>
<img src="img/other/cr.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/cr.png">Ambil</button>
</div>
<div class="balance tengah">
<div class="balance-content-other">
<div class="balance-currency">30 Unit</div>
<img src="img/other/cr.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/cr.png">Ambil</button>
</div>
<div class="balance kanan">
<div class="balance-content-other">
<div class="balance-currency">90 Unit</div>
<img src="img/other/cr.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/cr.png">Ambil</button>
</div>
<div class="balance kiri">
<div class="balance-content-other">
<div class="balance-currency">60 Unit</div>
<img src="img/other/cr.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/cr.png">Ambil</button>
</div>
<div class="balance tengah">
<div class="balance-content-other">
<div class="balance-currency">75 Unit</div>
<img src="img/other/cr.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/cr.png">Ambil</button>
</div>
</div> <!--- scroll --->
<script src="js/popup.js"></script>