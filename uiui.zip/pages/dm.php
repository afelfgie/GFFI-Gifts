<div class="menu-notify">
<a href="javascript:;" onclick="buka('pages/evostone');"><div class="menu-notify-change">Ganti Hadiah</div></a>
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, ini adalah hadiah gratisan untukmu</div>
</div> <!--- menu-notify --->
<div class="scroll">
<div class="balance kanan">
<div class="balance-content-cash">
<div class="balance-currency">1450 bonus 720</div>
<img src="img/other/dm.png">
<div class="balance-price"><del>200.000 IDR</del> - Gratis</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/dm1.png">Ambil</button>
</div>
<div class="balance kiri">
<div class="balance-content-cash">
<div class="balance-currency">355 bonus 140</div>
<img src="img/other/dm.png">
<div class="balance-price"><del>50.000 IDR</del> - Gratis</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/dm1.png">Ambil</button>
</div>
<div class="balance tengah">
<div class="balance-content-cash">
<div class="balance-currency">720 bonus 355</div>
<img src="img/other/dm.png">
<div class="balance-price"><del>100.000 IDR</del> - Gratis</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/dm1.png">Ambil</button>
</div>
<div class="balance kanan">
<div class="balance-content-cash">
<div class="balance-currency">7290 bonus 3640</div>
<img src="img/other/dm.png">
<div class="balance-price"><del>1.000.000 IDR</del> - Gratis</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/dm1.png">Ambil</button>
</div>
<div class="balance kiri">
<div class="balance-content-cash">
<div class="balance-currency">2180 bonus 1450</div>
<img src="img/other/dm.png">
<div class="balance-price"><del>300.000 IDR</del> - Gratis</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/dm1.png">Ambil</button>
</div>
<div class="balance tengah">
<div class="balance-content-cash">
<div class="balance-currency">3640 bonus 2180</div>
<img src="img/other/dm.png">
<div class="balance-price"><del>500.000 IDR</del> - Gratis</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/dm1.png">Ambil</button>
</div>
</div> <!--- scroll --->
<script src="js/popup.js"></script>