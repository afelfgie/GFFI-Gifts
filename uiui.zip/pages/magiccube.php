<div class="menu-notify">
<a href="javascript:;" onclick="buka('pages/cr');"><div class="menu-notify-change">Ganti Hadiah</div></a>
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, ini adalah hadiah gratisan untukmu</div>
</div> <!--- menu-notify --->
<div class="scroll">
<div class="balance kanan">
<div class="balance-content-other">
<div class="balance-currency">15 Unit</div>
<img src="img/other/magiccube.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/magiccube.png">Ambil</button>
</div>
<div class="balance kiri">
<div class="balance-content-other">
<div class="balance-currency">5 Unit</div>
<img src="img/other/magiccube.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/magiccube.png">Ambil</button>
</div>
<div class="balance tengah">
<div class="balance-content-other">
<div class="balance-currency">10 Unit</div>
<img src="img/other/magiccube.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/magiccube.png">Ambil</button>
</div>
<div class="balance kanan">
<div class="balance-content-other">
<div class="balance-currency">30 Unit</div>
<img src="img/other/magiccube.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/magiccube.png">Ambil</button>
</div>
<div class="balance kiri">
<div class="balance-content-other">
<div class="balance-currency">20 Unit</div>
<img src="img/other/magiccube.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/magiccube.png">Ambil</button>
</div>
<div class="balance tengah">
<div class="balance-content-other">
<div class="balance-currency">25 Unit</div>
<img src="img/other/magiccube.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/magiccube.png">Ambil</button>
</div>
</div> <!--- scroll --->
<script src="js/popup.js"></script>